# extension-cookie-stealer
roblox cookie exstention stealer

## virustotal 0/64
https://www.virustotal.com/gui/file-analysis/NTA5MmFiNTU5ZTcxY2M5NjQ0OWFhNDNjNTgyOGM0ZTg6MTcyNTg4NTkzNQ==

## How to setup
Put your own webhook in it
obfuscated to hide your webhooks

## Disclaimer
This extension is intended for educational and research purposes only. Do not use it for malicious activities.
